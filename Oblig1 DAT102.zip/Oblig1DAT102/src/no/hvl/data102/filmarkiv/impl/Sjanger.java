package no.hvl.data102.filmarkiv.impl;

public enum Sjanger {

}
