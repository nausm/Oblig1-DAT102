/**
 * 
 */
/**
 * 
 */
module Oblig1DAT102 {
	requires java.desktop;
	requires org.junit.jupiter.api;
}